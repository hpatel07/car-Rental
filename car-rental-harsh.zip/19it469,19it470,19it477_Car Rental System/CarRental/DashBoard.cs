﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace CarRental
{
    public partial class DashBoard : Form
    {
        public DashBoard()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\HARSH\OneDrive\Documents\CarRentaldb.mdf;Integrated Security=True;Connect Timeout=30");
        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void DashBoard_Load(object sender, EventArgs e)
        {
            string querycar = "select Count(*) from CarTb1";
            SqlDataAdapter sda = new SqlDataAdapter(querycar,Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CarLb.Text = dt.Rows[0][0].ToString();
            string querycust = "select Count(*) from CustomerTb1";
            SqlDataAdapter sda1 = new SqlDataAdapter(querycust, Con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            CustLb.Text = dt1.Rows[0][0].ToString();
            string queryuser = "select Count(*) from UserTb1";
            SqlDataAdapter sda2 = new SqlDataAdapter(queryuser, Con);
            DataTable dt2 = new DataTable();
            sda2.Fill(dt2);
            UserLb.Text = dt2.Rows[0][0].ToString();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainform main = new mainform();
            main.Show();
        }
    }
}
